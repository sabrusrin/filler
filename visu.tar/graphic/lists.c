/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   lists.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lkarlon- <lkarlon-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/17 19:13:38 by lkarlon-          #+#    #+#             */
/*   Updated: 2019/08/25 20:53:35 by lkarlon-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/fdf.h"

t_img	*new_img(int height, char *first_str, t_img *start_list)
{
	t_img	*new;
	char	*str;
	int 	i;

	i = -1;
	new = ft_memalloc(sizeof(t_img));
	new->next = NULL;
	new->field = ft_memalloc(sizeof(char*) * (height + 1));
	new->field[++i] = ft_strcccpy(first_str + 4, '\n');
	while(get_next_line(0, &str) && ft_isdigit(*str))
	{
		new->field[++i] = ft_strcccpy(str + 4, '\n');
		free(str);
	}	
	new->field[++i] = NULL;
	new->prev = start_list;
	start_list->next = new;
	return (new);
}

int	map_count(t_win *win)
{
	int			height;
	char		*str;
	
	while (get_next_line(0, &str))
	{
		if (ft_strstr(str, "Plateau"))
		{
			str += 8;
			height = ft_atoi(str);
			while (ft_isdigit(*str++))
				;
			win->width = ft_atoi(str);
			return (height);
		}
	}
	return (0);
}

/* void log_list(t_img *start, int height)
{
	int i;
	while (start->next && (i = -1))
	{	
		while (++i < height)
		{
			ft_putstr(start->field[i]);
			ft_putchar('\n');
		}
		ft_putchar('\n');
		start = start->next;
	}
} */

t_img	*create_first(int height)
{
	t_img	*new;
	char	*str;
	int 	i;

	i = -1;
	new = ft_memalloc(sizeof(t_img));
	new->next = NULL;
	new->field = ft_memalloc(sizeof(char*) * (height + 1));
	get_next_line(0, &str);
	while(get_next_line(0, &str) && ft_isdigit(*str))
	{
		new->field[++i] = ft_strcccpy(str + 4, '\n');
		free(str);
	}	
	new->field[++i] = NULL;
	new->prev = NULL;
	new->next = NULL;
	return (new);
}

t_img	*make_list(t_win *win)
{
	int			height;
	t_img		*block;
	t_img		*start_list;
	char		*str;
	
	height = map_count(win);
	win->height = height;
	block = create_first(height);
	start_list = block;
	while (get_next_line(0, &str))
	{
		if (ft_isdigit(*str))
			block = new_img(height, str, block);
	}
//	log_list(start_list, height);
	return (start_list);
}


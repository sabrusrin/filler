/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   vis.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lkarlon- <lkarlon-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/26 18:27:01 by lkarlon-          #+#    #+#             */
/*   Updated: 2019/08/22 18:12:15 by lkarlon-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../minilibx_macos/mlx.h"
#include "../../includes/fdf.h"
#include "../../includes/filler.h"
#include "../../includes/lists.h"

/* void		is_valid(t_win *win, int count)
{
	int v;
	int h;

	v = 0;
	win->widh = ft_count_words(win->coords[0], ' ');
	while (v < count)
	{
		h = 0;
		if ((int)ft_count_words(win->coords[v], ' ') != win->widh)
		{
			ft_error("Map error\n");
		}
		while (win->coords[v][h])
		{
			if (!ft_strchr(SYM, win->coords[v][h]))
				ft_error("Map error\n");
			h++;
		}
		v++;
	}
}

t_coords	*curr_init(t_point map_s, t_point map_e)
{
	t_coords *curr;

	curr = (t_coords*)malloc(sizeof(t_coords));
	curr->x0 = map_s.x;
	curr->x1 = map_e.x;
	curr->y0 = map_s.y;
	curr->y1 = map_e.y;
	curr->xc = curr->x0;
	curr->yc = curr->y0;
	if (map_s.z != map_e.z)
	{
		curr->color_start = 0xed0000;
		curr->color_end = 0x047f00;
	}
	else
	{
		curr->color_start = 0xed0000;
		curr->color_end = 0xed0000;
	}
	return (curr);
}

t_win		*win_init(char *s)
{
	t_win		*win;
	int			size;
	int			endian;
	int			bits;

	win = (t_win*)malloc(sizeof(t_win));
	win->mlx_ptr = mlx_init();
	win->win_ptr = mlx_new_window(win->mlx_ptr, W, H, s);
	win->img_ptr = (int*)mlx_new_image(win->mlx_ptr, W, H);
	win->addr = (int*)mlx_get_data_addr(win->img_ptr, &bits, &size, &endian);
//	win->coords = malloc(sizeof(char**) * (count));
	win->params.hight = H;
	win->params.widh = W;

	win->params.size = NET;
	//win->hight = count;
	return (win);
}

void		fdf(t_win *win, t_map *map, int y, int x)
{
	int			dx;
	int			dy;
	double		grad;
	t_coords	*curr;

	curr = curr_init(map_s, map_e);
	dx = (map_e.x > map_s.x) ? (map_e.x - map_s.x) : (map_s.x - map_e.x);
	dy = (map_e.y > map_s.y) ? (map_e.y - map_s.y) : (map_s.y - map_e.y);
	if (dx == 0 || dy == 0)
		draw_line(win, map_s, map_e);
	else if (dy < dx)
	{
		if (map_e.x < map_s.x)
			coords_rev(curr);
		grad = (double)dy / dx;
		draw_iterx(win, curr, grad);
	}
	else
	{
		if (map_e.y < map_s.y)
			coords_rev(curr);
		grad = (double)dx / dy;
		draw_itery(win, curr, grad);
	}
	free(curr);
}

void		print(t_map *map, t_win *win)
{
	int		y;
	int		x;

	y = 0;
	while (y < map->height)
	{
		x = 0;
		while (x < map->width)
		{
			////if (h < map->width - 1)
				fdf(win, map, y, x);
		//	if (v < map->height - 1)
			//	fdf(win, win->map[v][h], win->map[v + 1][h]);
			x++;
		}
		y++;
	}
	mlx_put_image_to_window(win->mlx_ptr, win->win_ptr, win->img_ptr, 0, 0);
}

void		draw_field(t_map *map)
{
	int			fd;
	t_win		*win;
	char		*str;
	int			i;
	
	win = win_init("Welcome to filler!");
	//win->map = build_net(win->coords, count, win->widh, win);
	print(map, win);
	mlx_key_hook(win->win_ptr, key_check, win);
	mlx_mouse_hook(win->win_ptr, mouse_check, win);
	mlx_loop(win->mlx_ptr);
}*/

void	draw_line(t_win *win, int y, int x)
{
	
	if (map_s.x == map_e.x)
		while (map_s.y <= map_e.y)
		{
			if (map_s.y >= 0 && map_s.y < H &&
			map_e.x >= 0 && map_e.x < W)
			{
				win->addr[(map_e.x + win->params.x_corr) +
				W * (map_s.y + win->params.y_corr)] = 0xff0000;
			}
			map_s.y++;
		}
	else if (map_s.y == map_e.y)
		while (map_s.x <= map_e.x)
		{
			if (map_s.x >= 0 && map_s.x < W &&
			map_e.y >= 0 && map_e.y < H)
			{
				win->addr[(map_s.x + win->params.x_corr) +
				W * (map_e.y + win->params.y_corr)] = 0xff0000;
			}
			map_s.x++;
		}
} 

t_map	*map_init()
{
	t_map	*map;
	char	*str;
	int		i;

	i = 0;
	map = (t_map*)malloc(sizeof(t_map));
	player_init(map);
	get_next_line(0, &str);
	str += 8;
	map->height = ft_atoi(str);
	while (ft_isdigit(*str++))
		;
	map->width = ft_atoi(str);
//	free(str);
	map->field = (char**)malloc(sizeof(char*) * map->height);
	map->warm_map = (int**)malloc(sizeof(int*) * map->height);
	while (i < map->height)
		map->warm_map[i++] = (int*)malloc(sizeof(int) * map->width);
	return (map);
}

void	map_make(t_map *map)
{
	char	*str;
	int		i;

	i = -1;
	while (get_next_line(0, &str))
	{
		if (ft_isdigit(*str))
			map->field[++i] = ft_strcccpy(str + 4, '\n');
		if (ft_strstr(str, "Piece"))
		{
			i = 0;
			map->h_p = ft_atoi(str + 6);
			while (ft_isdigit(*(str + 6 + i)))
				i++;
			map->w_p = ft_atoi(str + i + 6);
			map->piece = (char**)malloc(sizeof(char*) * map->h_p);
			i = -1;
			while (++i < (map->h_p) && get_next_line(0, &str))
				map->piece[i] = ft_strcccpy(str, '\n');
			warm_map(map);
			put_piece(map);
			i = -1;
		}
		free(str);
	}
}

t_win		*win_init(char *s)
{
	t_win		*win;
	int			size;
	int			endian;
	int			bits;

	win = (t_win*)malloc(sizeof(t_win));
	win->mlx_ptr = mlx_init();
	win->win_ptr = mlx_new_window(win->mlx_ptr, W, H, s);
	win->img_ptr = (int*)mlx_new_image(win->mlx_ptr, W, H);
	win->addr = (int*)mlx_get_data_addr(win->img_ptr, &bits, &size, &endian);
//	win->coords = malloc(sizeof(char**) * (count));
	//win->hight = count;
	return (win);
}

key_hook(int key, t_win *win)
{
	t_img *save;
	int x;
	int y;

	save = win;
	x = -1;
	y = -1;
	if (key == 53)
		exit(0);
	if (key == 124)
	{
		ft_bzero(win->addr, H * W * 4);
		mlx_put_image_to_window(win->mlx_ptr, win->win_ptr, win->img_ptr, 0, 0);
		while (win->start->field[++y][x])
			while (win->start->field[y][x++])
			{
				if (win->start->field[y][x] == '0')
				
			}
	}
	if (key == 126 || key == 125 || key == 123 || key == 124)
	{
		ft_bzero(win->addr, H * W * 4);
		push_img(win, key);
	}
	if (key == 27 || key == 24)
		z_scale(win, key);
	if (key == 40)
	{
		ft_bzero(win->addr, H * W * 4);
		mlx_put_image_to_window(win->mlx_ptr, win->win_ptr, win->img_ptr, 0, 0);
		print_k(win);
	}
	return (0);
}

void		draw_net(t_map *map, t_win *win)
{
//	t_win		*win;
	int		y;
	int		x;
	int		count_y;

	y = 0;
	count_y = 1;
//	win = win_init("Welcome to filler!");
	while (y < map->height * NET)
	{
		x = 0;
		while (x < map->width * NET)
		{
			if (!(count_y % NET) || count_y == 1) 
				win->addr[x + (W * y)] = 0xff0000;
			if (!((x + 1) % NET) || !x)
				win->addr[x + (W * y)] = 0xff0000;
			x++;
		}
		y++;
		count_y++;
	}
	mlx_put_image_to_window(win->mlx_ptr, win->win_ptr, win->img_ptr, 0, 0);
}

int		main()
{
	int		y;
	int		x;
	int		count_y;
	t_win		*win;
//	t_img		*start;

	//map = map_init();
	//y = 0;
	count_y = 1;
	win = win_init("Welcome to filler!");
	win->start = make_list;
	mlx_loop_hook (win->win_ptr, key_hook, win);
	mlx_put_image_to_window(win->mlx_ptr, win->win_ptr, win->img_ptr, 0, 0);
	mlx_loop(win->mlx_ptr);
	return (0);
}

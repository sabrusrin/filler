/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   visualisation.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: lkarlon- <lkarlon-@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/26 18:27:01 by lkarlon-          #+#    #+#             */
/*   Updated: 2019/08/25 21:57:09 by lkarlon-         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../minilibx_macos/mlx.h"
#include "../../includes/fdf.h"
//#include "../../includes/filler.h"
//#include "../../includes/lists.h"



t_win		*win_init(char *s)
{
	t_win		*win;
	int			size;
	int			endian;
	int			bits;

	win = (t_win*)malloc(sizeof(t_win));
	win->mlx_ptr = mlx_init();
	win->win_ptr = mlx_new_window(win->mlx_ptr, W, H, s);
	win->img_ptr = (int*)mlx_new_image(win->mlx_ptr, W, H);
	win->addr = (int*)mlx_get_data_addr(win->img_ptr, &bits, &size, &endian);
	return (win);
}

void print_square(t_win *win)
{
	int height;
	int width;
	int x;
	int y;
	int color;

	y = -1;
	while (win->start->field[++y] && (x = -1))
		while (win->start->field[y][++x] && (height = -1))
		{
			if (win->start->field[y][x] == 'O')
				color = 0x216900;
			else if (win->start->field[y][x] == 'o')
				color = 0x45f500;
			else if (win->start->field[y][x] == 'X')
				color = 0x0e5df0;
			else if (win->start->field[y][x] == 'x')
				color = 0x0ec6f0;
			else if (win->start->field[y][x] == '.')
				color = 0x000000;
			while (++height < (NET - 1) && (width = -1))
				while (++width < (NET - 1))
					win->addr[((x + width) + (x * (NET - 1))) + (((y + height) + (y * (NET - 1))) * W)] = color;
		}
}
void		draw_net(t_win *win)
{
	int		y;
	int		x;
	int		count_y;

	y = 0;
	count_y = 1;
	while (y < win->height * NET)
	{
		x = 0;
		while (x < win->width * NET)
		{
			if (!(count_y % NET) || count_y == 1) 
				win->addr[x + (W * y)] = 0xCC33CC;
			if (!((x + 1) % NET) || !x)
				win->addr[x + (W * y)] = 0xCC33CC;
			x++;
		}
		y++;
		count_y++;
	}
	mlx_put_image_to_window(win->mlx_ptr, win->win_ptr, win->img_ptr, 0, 0);
} 

void print_strings(t_win *win)
{
	mlx_string_put(win->mlx_ptr, win->win_ptr, 1000, 300, 0xFF3300, "Press:");
	mlx_string_put(win->mlx_ptr, win->win_ptr, 1000, 350, 0xFF3300, "Right to set the figure");
	mlx_string_put(win->mlx_ptr, win->win_ptr, 1000, 400, 0xFF3300, "Left to roll back");
	mlx_string_put(win->mlx_ptr, win->win_ptr, 1000, 450, 0xFF3300, "R for restart");
	mlx_string_put(win->mlx_ptr, win->win_ptr, 1000, 500, 0xFF3300, "Esc for exit");
}

int key_hook(int key, t_win *win)
{
	if (key == 53)
		exit(0);
	ft_bzero(win->addr, H * W * 4);
	mlx_put_image_to_window(win->mlx_ptr, win->win_ptr, win->img_ptr, 0, 0);
	if (key == 124)
	{
		print_square(win);
		if(win->start->next)
			win->start = win->start->next;
	}
	if (key == 123)
	{	
		if(win->start->prev)
			win->start = win->start->prev;
		print_square(win);
	}
	if (key == 15)
	{
		win->start = win->save;
		print_square(win);
	}
	draw_net(win);
	mlx_put_image_to_window(win->mlx_ptr, win->win_ptr, win->img_ptr, 0, 0);
	print_strings(win);
	return (0);
}



int		main()
{
	t_win		*win;

	win = win_init("Welcome to filler!");
	win->start = make_list(win);
	win->save = win->start;
	draw_net(win);
	print_strings(win);
	mlx_key_hook (win->win_ptr, key_hook, win);
	mlx_loop(win->mlx_ptr);
	return (0);
}
